#!/system/bin/sh

on_install() {
  $BOOTMODE || abort "- Installation From Recovery Not Supported!"
    TMPDIR="/data/adb/modules/ATWEAKER/"
    MODPATH="/data/adb/modules_update/ATWEAKER/"
      unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH &> /dev/null
      
     ui_print ""
     ui_print " - Please update Android tweaker module from telegram channel"
     ui_print " - Download latest module then install!"
        abort
    }